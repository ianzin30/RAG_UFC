"""Main chat content area."""
