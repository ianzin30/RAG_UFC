"""Left icon navigation rail."""
