"""Characterize current bugs, without fixing production or using real services.

Assertions of undesirable behavior document reproductions, not acceptance rules
for a future implementation. Replace them with desired invariants when fixed.
"""
import copy
import importlib
import json
from pathlib import Path
import sys

import pytest
from streamlit.testing.v1 import AppTest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'docs/analises'))
from streamlit_audit_support import Harness


@pytest.fixture
def audit(tmp_path,monkeypatch):
    # AppTest is in-process. Any accidental SDK, requests or retriever access fails.
    monkeypatch.setattr('socket.socket.connect',lambda *a,**kw:pytest.fail('Network forbidden in audit tests'))
    monkeypatch.setattr('socket.getaddrinfo',lambda *a,**kw:pytest.fail('DNS forbidden in audit tests'))
    with_fixture=Harness(tmp_path).install()
    yield with_fixture
    with_fixture.close()


def app():
    at=AppTest.from_string('from streamlit_audit_support import render\nrender()',default_timeout=10).run()
    assert not at.exception
    return at


def submit(at,text='Quem financia Atlas?'):
    at.chat_input[0].set_value(text).run()
    return at


def test_normal_send_and_rerun_execute_flow_once(audit):
    at=submit(app());assert not at.exception
    assert len(audit.calls)==1 and audit.calls[0]['history']==[]
    assert len(at.session_state.messages)==2
    at.run();assert not at.exception and len(audit.calls)==1
    assert len(at.session_state.messages)==2
    assert audit.instances[0].callback is None


@pytest.mark.parametrize('mode',['error','timeout'])
def test_error_is_not_retried_but_becomes_semantic_history(audit,mode):
    at=app();audit.mode=mode;submit(at)
    assert not at.exception and len(audit.calls)==1
    generic=at.session_state.messages[-1]['content']
    assert generic=='Nao consegui gerar a resposta agora. Tente novamente em instantes.'
    at.run();assert len(audit.calls)==1
    audit.mode='success';submit(at,'E agora?')
    assert any(m['role']=='assistant' and m['content']==generic for m in audit.calls[-1]['history'])


def test_identical_text_is_a_second_explicit_submission(audit):
    at=submit(app());submit(at)
    assert len(audit.calls)==2


def test_empty_answer_is_marked_complete_and_persisted(audit):
    audit.mode='empty';at=submit(app());assert not at.exception
    assert at.session_state.messages[-1]['content']==''
    assert any(s.label=='Resposta pronta.' and s.state=='complete' for s in at.status)


@pytest.mark.parametrize('mode',['abstain','clarification','empty_sources'])
def test_empty_citations_remain_empty_despite_legacy_sources(audit,mode):
    audit.mode=mode;at=submit(app());assert not at.exception
    assert at.session_state.messages[-1]['cited_sources']==[]
    at.run();assert not at.exception
    assert not any('Fonte citada' in m.value for m in at.markdown)


def test_profile_change_reuses_stale_service(audit):
    at=submit(app());audit.endpoint='https://synthetic.invalid/b'
    submit(at,'Outra pergunta')
    assert len(audit.instances)==1
    assert audit.calls[-1]['endpoint']=='https://synthetic.invalid/a'


def test_model_switch_updates_existing_provider_once(audit):
    at=submit(app());at.selectbox[0].select('audit-B').run()
    submit(at,'Outra pergunta')
    assert audit.models==['audit-B']
    assert audit.calls[-1]['model']=='audit-B' and len(audit.instances)==1


def test_collection_change_rebuilds_service(audit):
    at=submit(app())
    # initialize_chat_sessions restores the active chat, so change the chat owner.
    sessions=at.session_state.chat_sessions;sessions[0]['collection']=['audit-other']
    at.session_state['chat_sessions']=sessions
    submit(at,'Outra pergunta')
    assert audit.calls[-1]['collection']==['audit-other']
    assert len(audit.instances)==2


def test_mutated_active_chat_receives_late_result_risk_injection(audit):
    at=app()
    def change_chat(st):
        from presentation import chat_sessions
        chat_sessions.create_new_chat(default_collection=['audit'],default_model='audit-A')
    audit.during_call=change_chat;submit(at)
    sessions=at.session_state.chat_sessions
    original=next(x for x in sessions if x['id']==audit.calls[0]['chat_id'])
    current=next(x for x in sessions if x['id']==at.session_state.active_chat_id)
    assert original['messages'][-1]['role']=='user'
    assert current['id']!=original['id'] and current['messages'][-1]['role']=='assistant'


@pytest.mark.parametrize('field,value',[('model_name','audit-B'),('collection',['other'])])
def test_mutated_selection_does_not_bind_result_to_original_profile(audit,field,value):
    at=app()
    def change(st):st.session_state[field]=value
    audit.during_call=change;submit(at)
    assert not at.exception
    message=at.session_state.messages[-1]
    assert message['role']=='assistant' and 'request_id' not in message
    assert 'model_name' not in message and 'collection' not in message


def test_persistence_failure_is_not_shown_to_user(audit):
    at=app();old=audit.storage.read_text();audit.fail_storage=True;submit(at)
    assert not at.exception and at.session_state.messages[-1]['role']=='assistant'
    assert audit.storage.read_text()==old
    assert not at.error


def test_two_sessions_overwrite_a_newer_snapshot(audit):
    one=submit(app(),'Primeira pergunta');two=app()
    submit(one,'Pergunta nova da aba um')
    assert 'Pergunta nova da aba um' in audit.storage.read_text()
    two.run();assert not two.exception
    assert 'Pergunta nova da aba um' not in audit.storage.read_text()


def test_source_fields_survive_reload(audit):
    one=submit(app());two=app();assert not two.exception
    source=two.session_state.messages[-1]['cited_sources'][0]
    assert source['evidence_id']=='E1' and source['focus_spans'][0]['quote']=='Aurora'


def test_unknown_source_id_is_rendered_as_cited(audit):
    audit.mode='wrong_source';at=submit(app());assert not at.exception
    assert any('E999.' in m.value and 'Fonte citada' in m.value for m in at.markdown)


def test_duplicate_source_is_not_deduplicated(audit):
    audit.mode='duplicate_distinct';at=submit(app());assert not at.exception
    assert sum('Fonte citada' in m.value for m in at.markdown)==2


def test_shared_duplicate_source_object_collides_in_widget_keys(audit):
    audit.mode='duplicate_sources';at=submit(app())
    assert at.exception and any('same' in e.message and 'key=' in e.message for e in at.exception)


def test_malformed_source_crashes_after_ready_status(audit):
    audit.mode='invalid_source';at=submit(app())
    assert at.exception and any("get" in e.message for e in at.exception)
    assert any(s.label=='Resposta pronta.' for s in at.status)
    assert at.session_state.messages[-1]['role']=='user'


def test_missing_file_falls_back_to_visible_preview_error(audit):
    audit.mode='missing_file';at=submit(app());assert not at.exception
    assert any('Nao foi possivel abrir o Markdown' in m.value for m in at.markdown)


def test_mismatched_focus_quote_highlights_other_text(audit):
    audit.mode='invalid_focus';at=submit(app());assert not at.exception
    assert any('<mark class="source-focus-highlight">Atlas</mark>' in m.value for m in at.markdown)


def test_source_expander_checkbox_key_changes_after_rerun(audit):
    at=submit(app());keep_reference=at.session_state.messages[-1]['cited_sources'][0]
    key=at.checkbox[0].key
    at.checkbox[0].check().run();assert not at.exception
    assert at.checkbox[0].key!=key
    assert not at.checkbox[0].value
    assert keep_reference['evidence_id']=='E1'


def test_invalid_runtime_configuration_is_not_validated_at_settings_load(audit):
    from service.rag.v2.Config import load_settings
    audit.config['llm']['provider']='not-a-provider'
    llm,_=load_settings()
    assert llm.provider=='not-a-provider'
    from service.rag.v2.Providers import ProviderRegistry
    with pytest.raises(Exception,match='Unknown provider'):ProviderRegistry(llm).resolve('planner')


def test_runtime_config_cache_does_not_reload_toml_automatically(audit):
    from service.RuntimeConfig import get_runtime_config
    assert get_runtime_config().llm_model=='audit-A'
    audit.config['llm']['model']='audit-B'
    assert get_runtime_config().llm_model=='audit-A'


def test_environment_authority_changes_after_application_bootstrap(audit,tmp_path,monkeypatch):
    from service import RuntimeConfig
    from llm_client import LLMSettings
    env=tmp_path/'synthetic.env'
    env.write_text('LLM_MODEL=file-model\nLLM_API_KEY=synthetic-test-key\n')
    monkeypatch.setenv('LLM_MODEL','process-model')
    monkeypatch.setenv('LLM_API_KEY','synthetic-test-key')
    monkeypatch.setattr(RuntimeConfig,'ENV_FILE',env)
    monkeypatch.setattr(RuntimeConfig,'_ENV_LOADED',False)
    assert LLMSettings.from_env(env).model=='process-model'
    RuntimeConfig.load_project_environment()
    assert LLMSettings.from_env(env).model=='file-model'
